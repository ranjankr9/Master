Purpose : BAIDU Map Integration source file
============================================

Source Files :
********************************************
1. js/storeLocator.js  
	1.1	What it does : 
		A.  It reads csv configuration files to load baidu map service and store information
		B.	It contains implementation for showing stores, outlets, show rooms and current location on the map. 
		c.	It provides the user with the search capability based on the city, state and postal code.
		D. 	It prompts the user to provide the acceptance towards "Allow/Share Location" on browser.
		E.  It does the coordinate transformation at the run time while dealing with the current location of the user.
	1.2 Configuration Required : NA

2. js/extLibs/*.js  
	2.1 What it does :
		A. It contains third party JS plugin.
    2.2 Configuration Required : NA
 
3. images/*.png 
	3.1 What it does :
		A.	It contains the images/icons being shown the map.
	    
4. jsp/storeLocator.jsp 
	4.1	What it does :
		A.	Provides the UX design for the page containing the map to be shown to the useer on the site.
	4.2 Configuration Required :
		A.	Set "ak" with the app key obtained after register at baidu.com at the place of script src injection for baidu map.
5. css/*.css & css/fonts/* 
	5.1	What it does :
		A.	It contains stylesheet information for the page "html/index.html" page.
	5.2 Configuration Required : NA
		
6. config/*.csv 
	6.1	What it does :
		A.	baiduServiceInfo.csv : csv configuration file to store Baidu Service information.
		B. 	StoreInfo.csv : csv configuration file to Store information.
	6.2 Configuration Required : NA

7. How to run and Test :
	7.1	Run the application on any web/application server only as it contains dynamic page - jsp to handle map  
8. Sample URL to hit the MAP
   http://localhost:8080/TestLocator/jsp/storeLocator.jsp